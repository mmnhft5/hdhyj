document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault(); // منع إرسال النموذج الافتراضي

    const username = document.getElementById('username').value;
    const screenshot = document.getElementById('screenshot').files[0];
    const phone = document.getElementById('phone').value;

    // التحقق من أن جميع الحقول مليئة
    if (username && screenshot && phone) {
        // إظهار رسالة عند النجاح
        document.getElementById('message').textContent = "تم استلام الطلب بنجاح سيتم تفعيل الأداة الآن.";
        document.getElementById('form').reset(); // إعادة تعيين النموذج
    } else {
        // إظهار رسالة عند وجود حقول فارغة
        document.getElementById('message').textContent = "يرجى ملء جميع الحقول.";
    }
});
